#我们终将战胜疫情，20220524，xidian university
##导入库模块
import sys#“sys”即“system”，“系统”之意。该模块提供了一些接口，用于访问 Python 解释器自身使用和维护的变量，同时模块中还提供了一部分函数，可以与解释器进行比较深度的交互。

import math#c标准定义的数学函数
import pygame as py#游戏专用模块
from pygame.locals import *#将所有的 pygame 常量导入
import random#随机变量产生
import time#操控时间变量


##天数设置
infectedsettingdayss = random.randint(3, 14)#模拟无症状感染者感染天数
attackedsettingdayss = random.randint(1, 3)#模拟转为确诊天数
inhospitalsettingdayss = random.randint(5, 8)#模拟住院天数
##颜色设置
backgroundcolor = py.Color(180, 180, 180)#背景颜色
hospitalbackgroundcolor = py.Color(255, 255, 255)
defaultcolor=py.Color(0, 0, 0)
healthypeople = py.Color(0, 255, 0)
infectedpeople = py.Color(255, 255, 0)
attackedpeople = py.Color(255, 0, 0)
hospitalcolor = py.Color(128, 0, 0)
deadpeople = py.Color(0, 0, 0)
recoveredpeople = py.Color(255, 255, 255)
#预分配
attackednumbers = []#确诊数
ininhospitalnumberss = []#住院数
healthynumbers = []#健康数
infectednumbers = []#无症状感染数

#
bednumbers = 100#床位数为100
initinfectednumbers = 6#开始的无症状感染者数量为6
moveDistancePersettingdays = 12.0#每天移动距离（直线距离）为12
onmusk = 1
peoplesafedistance = 3 * 3 if onmusk else 10 * 10#安全距离为3*3，如果戴口罩变为10*10
windowsize = 700#窗口大小设置为700*700
citySize = 400#城市圆直径为400
totalpeoplenumbers = 1000#人总数为1000
deathrate = 0.5#死亡概率为0.5


class typeText:
    def displayText1(myself, settings1, settingdays):
        screenDisplayFont = py.font.SysFont("SimHei", 40)#设置字体为黑体
#
        screen1 = screenDisplayFont.render("天数:" + str(settingdays), True, defaultcolor)#变化数量
        screenRect1 = screen1.get_rect()
        screenRect1.midtop = (250, 10)#位置

        screenDisplay2 = screenDisplayFont.render("人数:" + str(totalpeoplenumbers), True, defaultcolor)
        screenRect2 = screenDisplay2.get_rect()
        screenRect2.midtop = (450, 10)

        settings1.blit(screen1, screenRect1)
        settings1.blit(screenDisplay2, screenRect2)
        py.display.flip()

    def displayText2(myself, settings1, healthynumbers, infectdenumbers, attackednumbers):
        screenDisplayFont = py.font.SysFont("SimHei", 40)
        screen1 = screenDisplayFont.render("健康者数" + str(healthynumbers), True, healthypeople)
        screenRect1 = screen1.get_rect()
        screenRect1.midtop = (120, 60)

        screenDisplay2 = screenDisplayFont.render("无症状数:" + str(infectdenumbers), True, infectedpeople)
        screenRect2 = screenDisplay2.get_rect()
        screenRect2.midtop = (350, 60)

        screenDisplay3 = screenDisplayFont.render("感染者数:" + str(attackednumbers), True, attackedpeople)
        screenRect3 = screenDisplay3.get_rect()
        screenRect3.midtop = (580, 60)

        settings1.blit(screen1, screenRect1)
        settings1.blit(screenDisplay2, screenRect2)
        settings1.blit(screenDisplay3, screenRect3)
        py.display.flip()

    def displayText3(myself, settings1, inhospitalnumbers, deadpeoplenumbers, recoverynumbers):
        screenDisplayFont = py.font.SysFont("SimHei", 40)
        screen1 = screenDisplayFont.render("住院数:" + str(inhospitalnumbers), True, hospitalcolor)
        screenRect1 = screen1.get_rect()
        screenRect1.midtop = (120, 110)

        screenDisplay2 = screenDisplayFont.render("死亡数:" + str(deadpeoplenumbers), True, deadpeople)
        screenRect2 = screenDisplay2.get_rect()
        screenRect2.midtop = (320, 110)

        screenDisplay3 = screenDisplayFont.render("确诊转阴数:" + str(recoverynumbers), True, hospitalbackgroundcolor)
        screenRect3 = screenDisplay3.get_rect()
        screenRect3.midtop = (560, 110)

        settings1.blit(screen1, screenRect1)
        settings1.blit(screenDisplay2, screenRect2)
        settings1.blit(screenDisplay3, screenRect3)
        py.display.flip()

    def displayText4(myself, settings1):
        screenDisplayFont = py.font.SysFont("SimHei", 50)
        screen1 = screenDisplayFont.render("城市生活环境", True, defaultcolor)
        screenRect1 = screen1.get_rect()
        screenRect1.midtop = (220, 600)

        screenDisplay2 = screenDisplayFont.render("医院:", True, defaultcolor)
        screenRect2 = screenDisplay2.get_rect()
        screenRect2.midtop = (480, 170)

        settings1.blit(screen1, screenRect1)
        settings1.blit(screenDisplay2, screenRect2)
        py.display.flip()

    def gameOver1(myself, settings1):
        gameOverFont = py.font.SysFont("SimHei", 140)
        gameOverSurf = gameOverFont.render("抗疫失败", True, attackedpeople)
        gameOverRect = gameOverSurf.get_rect()
        gameOverRect.midtop = (350, 260)
        settings1.blit(gameOverSurf, gameOverRect)
        py.display.flip()
        time.sleep(60)
        py.quit()
        sys.exit()

    def gameOver2(myself, settings1):
        gameOverFont = py.font.SysFont("SimHei", 140)
        gameOverSurf = gameOverFont.render("抗疫胜利", True, healthypeople)
        gameOverRect = gameOverSurf.get_rect()
        gameOverRect.midtop = (350, 260)
        settings1.blit(gameOverSurf, gameOverRect)
        py.display.flip()
        time.sleep(60)
        py.quit()
        sys.exit()


class typeHospital:
    def __init__(myself):
        myself.hospitalX = 560
        myself.hospitalY = 180
        myself.hospitalWidth = 80
        myself.hospitalHeight = 500
        myself.beds = bednumbers
        myself.bedSize = 10
        myself.dx = 0
        myself.dy = 0
        myself.step = 0

    def bedJudge(myself):
        return myself.beds > len(ininhospitalnumberss)

    def draw(myself, settings1):
        py.draw.rect(settings1, defaultcolor,
                         [myself.hospitalX, myself.hospitalY, myself.hospitalWidth, myself.hospitalHeight], 1)

        for i in range(myself.beds):
            myself.dx = myself.hospitalX + (i % 4) * 20 + 5
            myself.dy = myself.hospitalY + (i // 4) * 20 + 5
            py.draw.rect(settings1, backgroundcolor, [myself.dx, myself.dy, myself.bedSize, myself.bedSize], 0)

        myself.step = 0
        for i in poepleenvironment:
            if i.state == hospitalcolor:
                myself.dx = myself.hospitalX + (myself.step % 4) * 20 + 5
                myself.dy = myself.hospitalY + (myself.step // 4) * 20 + 5
                py.draw.rect(settings1, hospitalcolor, [myself.dx, myself.dy, myself.bedSize, myself.bedSize], 0)
                myself.step += 1

        py.display.flip()


class typePeople:
    def __init__(myself):
        myself.state = healthypeople
        myself.settingdayss = 0
        myself.peopleSize = 4
        myself.angle = round(random.uniform(0, 6.28), 2)
        myself.r = random.randrange(10, 180)
        myself.mypositonx = math.cos(myself.angle) * myself.r
        myself.mypositiony = math.sin(myself.angle) * myself.r
        myself.direction = round(random.uniform(0, 6.28), 2)
        myself.dx = 0
        myself.dy = 0
        myself.mypositonx1 = 0
        myself.mypositiony1 = 0
        myself.distance = 0

    def move(myself, settingdayss):
        if myself.state == hospitalcolor or myself.state == deadpeople:
            return
        myself.dx = moveDistancePersettingdays * math.cos(myself.direction)
        myself.dy = moveDistancePersettingdays * math.sin(myself.direction)
        myself.mypositonx1 = myself.mypositonx + myself.dx
        myself.mypositiony1 = myself.mypositiony + myself.dy
        myself.distance = myself.mypositonx1 ** 2 + myself.mypositiony1 ** 2
        if myself.distance < (citySize / 2 -10) ** 2:
            myself.mypositonx = myself.mypositonx1
            myself.mypositiony = myself.mypositiony1
        else:
            myself.direction = round(random.uniform(0, 6.28), 2)
            myself.move(settingdayss)


class typeCity:
    def __init__(myself):
        myself.templateid = []
        myself.peoplebetweendistance = 0
        myself.city_x = 220
        myself.cityY = 350
        myself.citySize = citySize

        myself.healthynumbers = 0
        myself.infectdenumbers = 0
        myself.attackednumbers = 0
        myself.inhospitalnumbers = 0
        myself.deadpeoplenumbers = 0
        myself.recoverynumbers = 0

        for a in range(totalpeoplenumbers):
            healthynumbers.append(a)
        for a in range(initinfectednumbers):
            x = random.randint(0, totalpeoplenumbers - 1)
            if poepleenvironment[x].state == healthypeople:
                poepleenvironment[x].state = infectedpeople
                poepleenvironment[x].settingdayss = infectedsettingdayss
                healthynumbers.remove(x)
                infectednumbers.append(x)

    def simulatesOnesettingdays(myself):
        myself.templateid = []
        for i in healthynumbers:
            for j in infectednumbers:
                myself.peoplebetweendistance = (poepleenvironment[i].mypositonx - poepleenvironment[j].mypositonx) ** 2 \
                                         + (poepleenvironment[i].mypositiony - poepleenvironment[j].mypositiony) ** 2
                if myself.peoplebetweendistance < peoplesafedistance:
                    myself.templateid.append(i)
                    break
        for i in myself.templateid:
            poepleenvironment[i].state = infectedpeople
            poepleenvironment[i].settingdayss = infectedsettingdayss
            healthynumbers.remove(i)
            infectednumbers.append(i)
        for i in range(totalpeoplenumbers):
            if poepleenvironment[i].state == infectedpeople:
                poepleenvironment[i].settingdayss -= 1
                if poepleenvironment[i].settingdayss <= 0:
                    poepleenvironment[i].state = attackedpeople
                    poepleenvironment[i].settingdayss = attackedsettingdayss
                    infectednumbers.remove(i)
                    attackednumbers.append(i)
                continue

            if poepleenvironment[i].state == attackedpeople:
                poepleenvironment[i].settingdayss -= 1
                if poepleenvironment[i].settingdayss <= 0:
                    if hospital.bedJudge():
                        attackednumbers.remove(i)
                        ininhospitalnumberss.append(i)
                        poepleenvironment[i].state = hospitalcolor
                        poepleenvironment[i].settingdayss = inhospitalsettingdayss
                    elif round(random.uniform(0, 1), 2) < deathrate:
                        attackednumbers.remove(i)
                        poepleenvironment[i].state = deadpeople
                    else:
                        attackednumbers.remove(i)
                        poepleenvironment[i].state = recoveredpeople

            if poepleenvironment[i].state == hospitalcolor:
                poepleenvironment[i].settingdayss -= 1
                if poepleenvironment[i].settingdayss <= 0:
                    poepleenvironment[i].state = recoveredpeople
                    ininhospitalnumberss.remove(i)
                    continue

    def draw(myself, settings1):
        py.draw.circle(settings1, defaultcolor, (myself.city_x, myself.cityY), myself.citySize / 2, 1)
        py.display.flip()

    def countPeople(myself):
        myself.attackednumbers = 0
        myself.inhospitalnumbers = 0
        myself.deadpeoplenumbers = 0
        myself.recoverynumbers = 0
        myself.healthynumbers = 0
        myself.infectdenumbers = 0

        for i in range(totalpeoplenumbers):
            if poepleenvironment[i].state == healthypeople:
                myself.healthynumbers += 1
            if poepleenvironment[i].state == infectedpeople:
                myself.infectdenumbers += 1
            if poepleenvironment[i].state == attackedpeople:
                myself.attackednumbers += 1
            if poepleenvironment[i].state == hospitalcolor:
                myself.inhospitalnumbers += 1
            if poepleenvironment[i].state == deadpeople:
                myself.deadpeoplenumbers += 1
            if poepleenvironment[i].state == recoveredpeople:
                myself.recoverynumbers += 1
poepleenvironment = []

text = typeText()

for i in range(totalpeoplenumbers):
    people = typePeople()
    poepleenvironment.append(people)
cityins = typeCity()
hospital = typeHospital()

def main():
    py.init()
    settings1 = py.display.set_mode((windowsize, windowsize))
    py.display.set_caption("我们终将战胜疫情")
    totalsettingdayss = 0
    while True:
        for event in py.event.get():
            if event.type == QUIT:
                py.quit()
                sys.exit()
        settings1.fill(backgroundcolor)
        py.time.Clock().tick(20)
        totalsettingdayss += 1
        cityins.countPeople()
        text.displayText1(settings1, totalsettingdayss)
        text.displayText2(settings1, cityins.healthynumbers, cityins.infectdenumbers, cityins.attackednumbers)
        text.displayText3(settings1, cityins.inhospitalnumbers, cityins.deadpeoplenumbers, cityins.recoverynumbers)
        text.displayText4(settings1)
        cityins.draw(settings1)
        hospital.draw(settings1)
        for i in poepleenvironment:
            if i.state != hospitalcolor:
                py.draw.rect(settings1, i.state,
                                 [220 + i.mypositonx, 350 + i.mypositiony, i.peopleSize, i.peopleSize], 0)
        for i in poepleenvironment:
            i.move(totalsettingdayss)
        cityins.simulatesOnesettingdays()
        if cityins.infectdenumbers == 0 and cityins.deadpeoplenumbers > totalpeoplenumbers / 2:
            text.gameOver1(settings1)
        elif cityins.infectdenumbers == 0 and cityins.deadpeoplenumbers <= totalpeoplenumbers / 2 and cityins.attackednumbers == 0:
            text.gameOver2(settings1)
        py.display.flip()

if __name__ == "__main__":
    main()
